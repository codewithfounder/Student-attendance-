var form = document.getElementById("myForm"),
    imgInput = document.querySelector(".img"),
    file = document.getElementById("imgInput"),
    userName = document.getElementById("name"),
    // age = document.getElementById("age"),
    city = document.getElementById("city"),
    // email = document.getElementById("email"),
    phone = document.getElementById("phone"),
    post = document.getElementById("post"),
    sDate = document.getElementById("sDate"),
    submitBtn = document.querySelector(".submit"),
    userInfo = document.getElementById("data"),
    modal = document.getElementById("userForm"),
    modalTitle = document.querySelector("#userForm .modal-title"),
    newUserBtn = document.querySelector(".newUser")

    // console.log(new Date().getDate())

// let record = localStorage.getItem('Student Record') ? JSON.parse(localStorage.getItem('Student Record')) : []
let record = localStorage.getItem('Student Record') ? JSON.parse(localStorage.getItem('Student Record')) : []

let isEdit = false, editId
showInfo()

newUserBtn.addEventListener('click', ()=> {
    submitBtn.innerText = 'Submit',
    modalTitle.innerText = "Fill the Form"
    isEdit = false
    imgInput.src = "./image/Profile Icon.webp"
    form.reset()
})


file.onchange = function(){
    if(file.files[0].size < 1000000){  // 1MB = 1000000
        var fileReader = new FileReader();

        fileReader.onload = function(e){
            imgUrl = e.target.result
            imgInput.src = imgUrl
        }

        fileReader.readAsDataURL(file.files[0])
    }
    else{
        alert("This file is too large!")
    }
}


function showInfo(){
    document.querySelectorAll('.employeeDetails').forEach(info => info.remove())
    record.forEach((element, index) => {
        let createElement = `
        
        <tr class="employeeDetails">
            <td>${index+1}</td>
            <td><img src="${element.picture}" alt="" width="50" height="50"></td>
            <td>${element.employeeName}</td>
            <td>${element.employeeCity}</td>
          <!--  <td>${element.employeeEmail}</td> -->
            <td>${element.employeePhone}</td>
            <td>${element.employeePost}</td>
            <td>${element.startDate}</td>


            <td>
            
            ${element.status==='absent'?`    <button class="btn btn-danger">${element.status}</button>`: `<button class="btn btn-success" >${element.status}</button>` }
                
                

            
                
                
            
                
                            
            </td>
        </tr>`
        
        userInfo.innerHTML += createElement
    })
}
showInfo()






//     // document.querySelector("#showAge").value = age,
//     document.querySelector("#showCity").value = city,
//     // document.querySelector("#showEmail").value = email,
//     document.querySelector("#showPhone").value = phone,
//     document.querySelector("#showPost").value = post,
//     document.querySelector("#showsDate").value = sDate
// }


// function editInfo(index, pic, name,  City, Phone, Post, Sdate){
//     isEdit = true
//     editId = index
//     imgInput.src = pic
//     userName.value = name
//     // age.value = Age
//     city.value =City
//     // email.value = Email,
//     phone.value = Phone,
//     post.value = Post,
//     sDate.value = Sdate

//     submitBtn.innerText = "Update"
//     modalTitle.innerText = "Update The Form"
// }


// function deleteInfo(index){
//     if(confirm("Are you sure want to delete?")){
//         record.splice(index, 1)
//         localStorage.setItem("Student Record", JSON.stringify(record))
//         showInfo()
//     }
// }


// form.addEventListener('submit', (e)=> {
//     e.preventDefault()

//     const information = {
//         picture: imgInput.src == undefined ? "./image/Profile Icon.webp" : imgInput.src,
//         employeeName: userName.value,
//         // employeeAge: age.value,
//         employeeCity: city.value,
//         // employeeEmail: email.value,
//         employeePhone: phone.value,
//         employeePost: post.value,
//         startDate: sDate.value
//     }

//     if(!isEdit){
//         record.push(information)
//     }
//     else{
//         isEdit = false
//         record[editId] = information
//     }

//     localStorage.setItem('Student Record', JSON.stringify(record))

//     submitBtn.innerText = "Submit"
//     modalTitle.innerHTML = "Fill The Form"

//     showInfo()

//     form.reset()

//     imgInput.src = "./image/Profile Icon.webp"  

//     // modal.style.display = "none"
//     // document.querySelector(".modal-backdrop").remove()
// })