

let showdate = document.querySelector('.showdate');
// let stimedate = document.querySelector('.stimedate');
// console.log(stimedate.innerHTML = 'hello')
const today = new Date()

const da = today.toLocaleDateString()
showdate.innerHTML = da;

// localStorage.setItem('Date',da)
